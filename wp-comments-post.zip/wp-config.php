<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'resume');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '!cz.dniVf2&p|,uKXLPl@$f1oRtl<Bwt4m(D?ft 8gt@vSL;W,#YEkBD|5,y:S!q');
define('SECURE_AUTH_KEY',  'H[*L[3~v;4=6]6}>N|JdV]/[~Ut>:qYPrd@6{K ~1#a}M3+;w_)4(uB>}c_/ts6y');
define('LOGGED_IN_KEY',    'p-/>#9$o>s%R5@t.;y,*qAAeRd+4kQo;)3FP{10fe!;&b/mt~*Qn{?].]i{9%/GX');
define('NONCE_KEY',        '(]G`%f[6:LT2$N5pwiZ-w>1 p>/o-raRA31>4;$CjJ}:~>aRm:zTah|Ac)ryMrf)');
define('AUTH_SALT',        '.:]?b&PWSB[A$0_bt{xJ1DX*yfJ%Rr6KKj|/I><(;@QU,E#>,o )iYN]XEZhJibi');
define('SECURE_AUTH_SALT', ';na}fD1;&=4RoRJK[bQ9~RS7n:zSJk2m%aQ(v#SkH%o#8u] >&Sfe~0PTfP.Tai:');
define('LOGGED_IN_SALT',   '!H?t}x5%F{ ;Tr^w2vdShp{V:l|U^VWCS;Y5}[;?tR1~fe(_0Be!bCWGd#&=;<ZU');
define('NONCE_SALT',       '=(EFzgY0a2aVO!E.xkpPAG?@XOx9p{Q$:sr^gcO72P_x@PPPj=)rcd<#Npqf)W+=');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
